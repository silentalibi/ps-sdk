// JavaScript Document
var titleStringWithHTML = "Adobe<sup>&reg;</sup> Photoshop<sup>&reg;</sup> CC SDK";
var titleString = "Adobe Photoshop SDK";
var appStringPlain = "Photoshop CC";
var appWithVersion = "Adobe Photoshop CC";
var appPSSC4 = "Adobe Photoshop CS4";
var minVersion = "17.0.0";
var appWithVersionWithHTML = "Adobe<sup>&reg;</sup> Photoshop<sup>&reg;</sup> CC";
var appHTMLWithAllVersion = "Adobe<sup>&reg;</sup> Photoshop<sup>&reg;</sup>CS4, CS5 and CS6";
var companionSDKName = "Photoshop Connection SDK";

document.title = titleString;
